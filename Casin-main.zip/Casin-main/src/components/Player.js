import React from 'react';
import { useEffect, useState } from 'react';
import styled from 'styled-components';
import Pot from './Pot';

const PlayerWrapper = styled.div`
  position: absolute;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  transform: translate(-50%, -50%);
  z-index: 10;
  width: 100%;
`;


const Avatar = styled.img`
  width: 5%;
  height: 5%;
  border-radius: 50%;
`;

const Player = ({ avatar, name, index, totalPlayers, tableCenter, tableDimensions, tableDimensionsP,tableCenterP, score, balanceImage,meter, color, label, labelColor, backgroundImage, mute, nocamera, det, eyeImage }) => {

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [potPosition, setPotPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const updatePosition = () => {
      const angle = (360 / totalPlayers) * index;
      const radiusX = tableDimensions.width / 2 + 60;
      const radiusY = tableDimensions.height / 2 + 40;
      const x = tableCenter.x + radiusX * Math.cos((angle * Math.PI) / 180);
      const y = tableCenter.y + radiusY * Math.sin((angle * Math.PI) / 180);
  
      const potRadiusX = tableDimensionsP.width / 2 + 2;
      const potRadiusY = tableDimensionsP.height / 2 + 2;
      const potX = tableCenterP.x + potRadiusX * Math.cos((angle * Math.PI) / 180);
      const potY = tableCenterP.y + potRadiusY * Math.sin((angle * Math.PI) / 180);
  
      setPosition({ x, y });
      setPotPosition({ x: potX, y: potY });
    };
  
    updatePosition();
    window.addEventListener('resize', updatePosition);
  
    return () => {
      window.removeEventListener('resize', updatePosition);
    };
  }, [index, totalPlayers, tableCenter, tableDimensions, tableCenterP, tableDimensionsP]);
  
  return (
   <>

     <PlayerWrapper style={{ left: `${position.x}px`, top: `${position.y}px` }}>
      <Avatar src={avatar} alt={`${name}'s avatar`} />
    </PlayerWrapper>

    <Pot
        balanceImage={balanceImage}
        score={score}
        color={color}
        label={label}
        labelColor={labelColor}
        backgroundImage={backgroundImage}
        position={potPosition}
        meter={meter}
        nocamera={nocamera}
        mute={mute}
        det={det}
        eyeImage={eyeImage}
      />


    <Pot balanceImage={balanceImage}
     score={score} 
     color={color}
      label={label} 
      labelColor={labelColor}
      backgroundImage={backgroundImage}
      position={potPosition}
       meter={meter} 
       nocamera={nocamera} 
       mute={mute} 
       det={det} 
       eyeImage={eyeImage} />
   </>
  );
};

export default Player;

